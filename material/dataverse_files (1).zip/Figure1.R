# Create Figure 1
# Ho, Imai, King, and Stuart (2007)
# MatchIt version 2.2-11

library(lattice)
library(MatchIt)

# Data saved was corrupted, so have to recreate.  
load("Figure1.Rdata")

lm.all1 <- lm(y ~ t+x, data=dta)
print("Full group: linear model beta")
print(lm.all1$coef[2])
lm.all2 <- lm(y ~ t+x+I(x^2), data=dta)
print("Full group: quadratic model beta")
print(lm.all2$coef[2])
temp <- matchit(t ~ x, data=dta)
matched <- match.data(temp)
lm.m1 <- lm(y ~ t+x, data=matched)
print("Matched group: linear model beta")
print(lm.m1$coef[2])
lm.m2 <- lm(y ~ t+x+I(x^2), data=matched)
print("Full group: quadratic model beta")
print(lm.m2$coef[2])

plot.pts <- seq(from=min(dta$x),to=max(dta$x),by=0.1)
plot.pts2 <- seq(from=5, to=24, by=0.1)

write.table(dta, file="Figure1Data.txt", row.names=FALSE)
 
trellis.device(device="pdf",file="olspanel-sept06.pdf",color=FALSE,width=8,height=4)
par(mar=c(2, 2, 2, 2) + 0.1, cex.lab=0.7, cex.axis=0.5,
    mgp=c(1,0.5,0), cex.main=0.8, cex=1, mfrow=c(1,2), bg="white")
plot(dta$x[dta$t==1],dta$y[dta$t==1],pch="T",
     xlim=range(dta$x), ylim = range(dta$y),
     xlab="X", ylab = "Y", cex=0.8, main="Before Matching")
points(dta$x[dta$t==0],dta$y[dta$t==0],pch="C", cex=0.8)
abline(lm.all1$coef[1] + lm.all1$coef[2], lm.all1$coef[3], lty=1, lwd=1.5)
abline(lm.all1$coef[1], lm.all1$coef[3], lty=1, col="darkgrey", lwd=1.5)
lines(plot.pts, lm.all2$coef[1] + lm.all2$coef[2] +
     lm.all2$coef[3]*plot.pts + lm.all2$coef[4]*plot.pts^2,
      lty=2, lwd=1.5)
lines(plot.pts, lm.all2$coef[1] + lm.all2$coef[3]*plot.pts +
      lm.all2$coef[4]*plot.pts^2, lty=2, col="darkgrey", lwd=1.5)
legend(5, 4.75, lty=c(1, 1, 2, 2), col=c(1, 8, 1, 8), lwd=1.5,
               legend=c("Linear Model, Treated Group",
                 "Linear Model, Control Group",
                 "Quadratic Model, Treated Group",
                 "Quadratic Model, Control Group"), cex=0.5)
plot(matched$x[matched$t==1], matched$y[matched$t==1],
     pch="T", xlab="X", ylab="Y", xlim=range(dta$x),
     ylim=range(dta$y), cex=0.8, main="After Matching")
points(matched$x[matched$t==0], matched$y[matched$t==0], pch="C", cex=0.8)
points(dta$x[temp$weights==0 & dta$t==0],
       dta$y[temp$weights==0 & dta$t==0],
       pch="C", col="darkgrey", cex=0.8)
lines(plot.pts2, lm.m1$coef[1] + lm.m1$coef[2] + lm.m1$coef[3]*plot.pts2, lty=1, lwd=1.5)
lines(plot.pts2, lm.m1$coef[1] + lm.m1$coef[3]*plot.pts2, lty=1, col="darkgrey", lwd=1.5)
lines(plot.pts2, lm.m2$coef[1] + lm.m2$coef[2] +
      lm.m2$coef[3]*plot.pts2 + lm.m2$coef[4]*plot.pts2^2,
      lty=2, lwd=1.5)
lines(plot.pts2, lm.m2$coef[1] + lm.m2$coef[3]*plot.pts2 +
      lm.m2$coef[4]*plot.pts2^2, lty=2, col="darkgrey", lwd=1.5)
legend(5, 4.75, lty=c(1, 1, 2, 2), col=c(1, 8, 1, 8), lwd=1.5,
       legend=c("Linear Model, Treated Group",
         "Linear Model, Control Group",
         "Quadratic Model, Treated Group",
         "Quadratic Model, Control Group"), cex=0.5)
dev.off()


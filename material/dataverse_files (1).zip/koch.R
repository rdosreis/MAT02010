# Koch replication
# Zelig version 2.6-4; MatchIt version 2.2-11; R version 2.3.1
rm(list=ls())
library(MatchIt)
library(foreign)
library(Zelig)
library(mvtnorm)
library(combinat)
library(lattice)

source("fn.R")
dta <- read.table("Visibility-Koch.csv", header=TRUE, sep=",")

#======================================
# Model 3 (Republican Male Candidates)
#======================================
#creating full dataset 
dta.full <- subset(dta, subset=c(repman==1 & voter==1))
dta.full <- na.omit(dta.full)

# Matching and creating matched dataset
fml <- as.formula(prcanid ~ I(rvisman==0) + repcan1 + goppty + rideo +
                  rproj + repft + aware)
res <- zelig(fml, data=dta.full, model="ls")
xvars <- names(res$coefficients)
xvars <- xvars[3:length(xvars)]
tt <- attr(terms(res),"term.labels")[1]
yy <- attr(terms(res),"variables")[[2]]
mfml <- as.formula(paste(tt,"~",paste(xvars,collapse=" + ")))
m1 <- matchit(mfml, method="nearest", data=dta.full)
dta.match <- match.data(m1)
dta.full.controls <- subset(dta.full,subset=c(dta.full$rvisman!=0))
dta.full.treated <- subset(dta.full,subset=c(dta.full$rvisman==0))
dta.match.controls <- dta.match[dta.match$rvisman!=0,]
dta.match.treated <- dta.match[dta.match$rvisman==0,]
summary(m1)

# QQ Plot
pdf("kochqq.pdf", paper="special", height=4, width=4)
par(mar=c(2.5, 2.5, 2, 2) + 0.1, cex.lab=0.8, cex.axis=0.8,
    mgp=c(1.5,0.5,0), cex.main=0.8, cex=0.8, bg="white")
eqqplot(m1$distance[m1$treat==1],m1$distance[m1$treat==0],
        xlim=range(m1$distance),ylim=range(m1$distance),
        main="QQ Plot of Propensity Score",
        xlab="Treated Units", ylab="Control Units",
        pch=16, cex=0.5)
abline(a=0,b=1)
eqqplot(m1$distance[m1$treat==1 & m1$weights==1],
        m1$distance[m1$treat==0 & m1$weights==1], addit=T)
text(0.27,0.42,"Matched Data",cex=0.8)
text(0.45,0.24,"Raw Data",cex=0.8)
dev.off()

# Outcome Regression
summary(lm(fml, data=dta.full))
summary(lm(fml, data=dta.match))

# Total number of cells
cc <- apply(dta.full[,xvars],2,table)
tc <- 2 #2 treatment values
for(i in 1:length(cc)){
#  print(length(cc[[i]]))
  tc <- tc*length(cc[[i]])
}

# Sensitivity
# conditional effects ==========
start <- paste(yy,"~") #conditional effects
coef <- mcoef <- NULL
N <- 1
total <- 1
for (i in N:(length(xvars)-1))
  total <- total + ncol(combn(xvars, i)) 
cat("\n I'm going to run", total, "regressions!\n")

cil <- mcil <- coef <- mcoef <- rep(0,total)
counter <- 1
for (i in N:(length(xvars)-1)) {
  allsubset <- combn(xvars, i)
  for (j in 1:ncol(allsubset)) {
    ftmp <- start
    for (k in 1:i)
      ftmp <- paste(ftmp, "+", allsubset[k,j])
    ftmp <- as.formula(ftmp)
    #conditional effects ============
    res0 <- zelig(ftmp,
                  data=dta.full.controls, model="ls")
    xout0 <- setx(res0,data=dta.full.treated,cond=T)
    out0 <- sim(res0,x=xout0)
    quant0 <-  quantile(out0$qi$att.ev,c(0.025,0.95))
    cil[counter] <- quant0[2]-quant0[1]
    coef[counter] <- mean(out0$qi$att.ev)
    res1 <- zelig(ftmp,
                  data=dta.match.controls, model="ls")
    xout1 <- setx(res1,data=dta.match.treated,cond=T)
    out1 <- sim(res1,x=xout1)
    quant1 <-  quantile(out1$qi$att.ev,c(0.025,0.95))
    mcil[counter] <- quant1[2]-quant1[1]
    mcoef[counter] <- mean(out1$qi$att.ev)
    counter <- counter + 1
  }
  cat(i,"covariates:",counter,"\n")
  cat(date(), "\n\n")
  # conditional effects =============
  res0 <- zelig(prcanid ~ repcan1 + goppty + rideo +
                  rproj + repft + aware,
                data=dta.full.controls, model="ls")
  xout0 <- setx(res0,data=dta.full.treated,cond=T)
  out0 <- sim(res0,x=xout0)
  quant0 <-  quantile(out0$qi$att.ev,c(0.025,0.95))
  cil[counter] <- quant0[2]-quant0[1]
  coef[counter] <- mean(out0$qi$att.ev)
  res1 <- zelig(prcanid ~ repcan1 + goppty + rideo +
                  rproj + repft + aware,
                data=dta.match.controls, model="ls")
  xout1 <- setx(res1,data=dta.match.treated,cond=T)
  out1 <- sim(res1,x=xout1)
  quant1 <-  quantile(out1$qi$att.ev,c(0.025,0.95))
  mcil[counter] <- quant1[2]-quant1[1]
  mcoef[counter] <- mean(out1$qi$att.ev)  
}
#CI lengths
mean(cil)
mean(mcil)

pdf("kochdens.pdf", paper="special", height=3.5, width=6)
par(mar=c(2.5, 2.5, 2, 2) + 0.1, cex.lab=0.8, cex.axis=0.8,
    mgp=c(1.5,0.5,0), cex.main=0.5, cex=0.8, bg="white")
doverlay(mcoef,coef,lwd=2, bw=0.004,
         xlab="Estimated average treatment effect", leg=F)
arrows(-0.01,22, coefficients(res)[2],0, length=0.1)
text(0.07,12,"Raw data")
text(-0.07,50,"Matched\ndata")
text(-0.01,27,"Point estimate \n of raw data")
dev.off()

#saving image
save.image("koch-11-7-05.Rdata")


This is a replication data file for Daniel Ho, Kosuke Imai, Gary King,
and Elizabeth Stuart."Matching as Nonparametric Preprocessing for
Improving Parametric Causal Inference," Political Analysis,
forthcoming, 2007, copy at
http://gking.harvard.edu/files/abs/matchp-abs.shtml.

Below are the files relevant for each Table and Figure in this article.  The programs were run using R Version 2.3.1.  
MatchIt and Zelig versions given in the .R programs below.

Figure 1:
Figure1Data.txt, Figure1.Rdata (data files)
Figure1.R (R program)
olspanel-Sept06.pdf (the resulting figure)

Table 1 (FDA):
matchfda.R (R program to run the models and table and figure programs)
fdatable.R (R program to create the table)
matchfda.out (output from matchfda.R)
fn.R (R program with functions used in matchfda.R and koch.R)
FDA-Carpenter.csv (Carpenter's data read by matchfda.R; selected variables from full data set)

Figure 2 (FDA):
fdafigure.R (R program to create the figure)
fdadens.pdf (the resulting figure)

Figures 3 and 4 (Koch):
koch.R (R program to run the models, create Figures 3 and 4)
Visibility-Koch.csv (Koch's data, read by koch.R; selected variables from full data set)
kochqq.pdf (Figure 3)
kochdens.pdf (Figure 4)


